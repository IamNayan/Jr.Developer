package nayan;

import java.sql.DriverManager;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Qu {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
			Statement stmt = conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from ex");
			Queue<String> qN = new LinkedList<>();
			System.out.println("=========");
			int j;
			while(rs.next())
			{
				qN.add(rs.getString(1));
				
				
			}
			for (String name : qN) {
			    System.out.println(name);
			}
			System.out.println("==========");
			
			
			
			
			
			/*String[] aa={"Ma","Sa","S","ssds"};
			Queue<String> queueNames = new LinkedList<>();
			
			for(int i=0;i<aa.length;i++){
			queueNames.add(aa[i]);}
			System.out.println("=====================");
			for(String a:queueNames)
			{
				System.out.println(a);
			}*/
			/*while(rs.next())
			{
				System.out.println(rs.getString(1));
			}*/
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        
		
	}

}
