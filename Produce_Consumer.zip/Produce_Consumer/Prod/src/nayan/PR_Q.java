package nayan;

import java.lang.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.io.*;
import java.util.LinkedList;
import java.util.Queue;
import java.sql.Connection;
import java.sql.PreparedStatement;


public class PR_Q {

    public static void main(String[] args) throws InterruptedException {

    	PCaCC pcObject = new PCaCC();

        Thread pThread = new Thread(new Runnable() {
            @Override
            public void run() {

                try {
                    pcObject.produce();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });


        Thread cThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    pcObject.consume();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });


        pThread.start();
        cThread.start();

        pThread.join();
        cThread.join();
    }
}

class Qu1 {

	public void getQ() throws SQLException {
		// TODO Auto-generated method stub
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
			Statement stmt = conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from ex");
			Queue<String> qN = new LinkedList<String>();
			System.out.println("=========");
			int j;
			while(rs.next())
			{
				for(j=1;j<qN.size();j++){
				qN.add(rs.getString(j));}				
				System.out.println(rs.getString(j));
			}			
			
			/*String[] aa={"Ma","Sa","S","ssds"};
			Queue<String> queueNames = new LinkedList<>();
			
			for(int i=0;i<aa.length;i++){
			queueNames.add(aa[i]);}
			System.out.println("=====================");
			for(String a:queueNames)
			{
				System.out.println(a);
			}*/
			/*while(rs.next())
			{
				System.out.println(rs.getString(1));
			}*/
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        
		
	}

}
class PCaCC {
	
	Qu1 q=new Qu1();
	

    List<Integer> list = new ArrayList<>();

    public void produce() throws InterruptedException {
    	try {
			q.getQ();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        int val = 0;
        while(true) {

            synchronized (this) {

                if(list.size() != 0) this.wait();

                System.out.println("Produced : " + val);
                list.add(val++);

                notify();
                Thread.sleep(2000);
            }
        }
    }


    public void consume() throws InterruptedException {

        while(true) {

            synchronized (this) {

                if(list.size() == 0) this.wait();

                System.out.println("Consumed : " + list.get(0));

                list.remove(0);

                notify();
                Thread.sleep(2000);
            }
        }
    }
}