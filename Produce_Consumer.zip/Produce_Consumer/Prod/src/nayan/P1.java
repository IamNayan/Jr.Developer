package nayan;

import java.util.LinkedList;
import java.util.Queue;

public class P1 implements Runnable {

	private int eid;
	private String fname;
	private String mname;
	private String lname;
	public P1() {
		//super();
		// TODO Auto-generated constructor stub
	}	
	
	
	public P1(int eid, String fname, String mname, String lname) {
		super();
		this.eid = eid;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
	}
	public int getEid() {
		return eid;
	}


	public void setEid(int eid) {
		this.eid = eid;
	}


	public String getFname() {
		return fname;
	}



	public void setFname(String fname) {
		this.fname = fname;
	}



	public String getMname() {
		return mname;
	}



	public void setMname(String mname) {
		this.mname = mname;
	}



	public String getLname() {
		return lname;
	}



	public void setLname(String lname) {
		this.lname = lname;
	}

	Qq q;
	public P1(Qq q)
	{
	this.q=q;
	Thread t=new Thread(this,"P1");
	t.start();
	}
	public void run(){
    Queue<P1> qN = new LinkedList<>();;
	while(true)
	{
	q.put(qN);
	try{Thread.sleep(5000);}catch(Exception e){}
	}
	}
	


	@Override
	public String toString() {
		return "Pro " +"\n"+ "id=" + eid + ", fname=" + fname + ", mname=" + mname + ", lname=" + lname +"\n";
	}
	
	
	
}
