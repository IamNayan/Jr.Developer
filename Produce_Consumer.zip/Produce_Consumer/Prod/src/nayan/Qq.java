package nayan;

import java.util.Queue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.Queue;

public class Qq {

	int num;
	boolean valueSet=false;
	private Queue<P1> ListPeopleQ;
	static int count=0;
	Queue<P1> qN = new LinkedList<>();
	Queue<P1> qC = new LinkedList<>();;
	ResultSet rs;
	Statement stmt;
	public synchronized void put(Queue<P1> qN)
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
			stmt = conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from emp");			
			System.out.println("=========");
			while(rs.next())
			{
			
				qN.add(new P1(rs.getInt(1),
						rs.getString(2),
						rs.getString(3),
						rs.getString(4)));				
				
		    }
			rs=stmt.executeQuery("select count(*) as rowcount from emp");
			if(rs.next()){
				count=rs.getInt("rowcount");
			}
			System.out.println(count);
			while(count==0)
			{
			try{wait();}catch(Exception e){}
			}
			for (P1 name : qN) {
			    System.out.println(name);
			}				
			//System.out.println("Put :" +qN);
			//this.qN=qN;
			if(count!=0){
			notify();}
			
		}catch(Exception e){e.printStackTrace();}		
		
		
		
	}


	public synchronized void get(Queue<P1> qN) throws SQLException
	{			
		
	   System.out.println("=====remove====");			
	   while(count!=0)
	   {
	     try{wait();}catch(Exception e){}
	   }
	   while(rs.next())
		{
		
			qN.remove(new P1(rs.getInt(1),
					rs.getString(2),
					rs.getString(3),
					rs.getString(4)));				
			
	    }
	   System.out.println("Get :" +qN);
	   if(count==0){
	   notify();}
	}

}
