package nayan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.Queue;

public class DbCon {
  private Queue<P1> ListPeopleQ;
	public static void main(String[] args) throws SQLException {
		
		Qq q= new Qq();
		new P1(q);
		new C1(q);
		
		
		
		// TODO Auto-generated method stub

		/*try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
			Statement stmt = conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from emp");
			Queue<P1> qN = new LinkedList<>();
			System.out.println("=========");
			int j;
			while(rs.next())
			{
			
				qN.add(new P1(rs.getInt("eid"),
						rs.getString("ename"),
						rs.getString("mname"),
						rs.getString("lname")));				
				
			}			
			
			System.out.println(qN);
			String[] aa={"Ma","Sa","S","ssds"};
			Queue<String> queueNames = new LinkedList<>();
			
			for(int i=0;i<aa.length;i++){
			queueNames.add(aa[i]);}
			System.out.println("=====================");
			for(String a:queueNames)
			{
				System.out.println(a);
			}
			while(rs.next())
			{
				System.out.println(rs.getString(1));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        
		
	}*/
	}
		
	}


