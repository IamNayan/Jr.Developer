package nayan;

import java.lang.*;
import java.util.*;
import java.io.*;


public class P {

    public static void main(String[] args) throws InterruptedException {

    	PCaC pcObject = new PCaC();

        Thread pThread = new Thread(new Runnable() {
            @Override
            public void run() {

                try {
                    pcObject.produce();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });


        Thread cThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    pcObject.consume();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });


        pThread.start();
        cThread.start();

        pThread.join();
        cThread.join();
    }
}


class PCaC {

    List<Integer> list = new ArrayList<>();

    public void produce() throws InterruptedException {

        int val = 0;
        while(true) {

            synchronized (this) {

                if(list.size() != 0) this.wait();

                System.out.println("Produced : " + val);
                list.add(val++);

                notify();
                Thread.sleep(2000);
            }
        }
    }


    public void consume() throws InterruptedException {

        while(true) {

            synchronized (this) {

                if(list.size() == 0) this.wait();

                System.out.println("Consumed : " + list.get(0));

                list.remove(0);

                notify();
                Thread.sleep(2000);
            }
        }
    }
}