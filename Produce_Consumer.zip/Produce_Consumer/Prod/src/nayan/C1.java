package nayan;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.Queue;

public class C1 implements Runnable{

	private int id;
	private String fname;
	private String mname;
	private String lname;
	
	
	
	public C1() {
		//super();
		// TODO Auto-generated constructor stub
	}
	
	
	public C1(int id, String fname, String mname, String lname) {
		super();
		this.id = id;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
	}


	Qq q;
	public C1(Qq q)
	{
	this.q=q;
	Thread t=new Thread(this,"C1");
	t.start();
	}
	public void run(){
	Queue<P1> qN = new LinkedList<>();;

	while(true)
	{
	try {
		q.get(qN);
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	try{Thread.sleep(5000);}catch(Exception e){}
	}
	}
	@Override
	public String toString() {
		return "C1 [id=" + id + ", fname=" + fname + ", mname=" + mname + ", lname=" + lname + "]";
	}
	
	
	
}
