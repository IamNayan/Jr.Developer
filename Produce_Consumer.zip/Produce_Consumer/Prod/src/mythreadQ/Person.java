package mythreadQ;

public class Person {

	private int eid;
	private String fname;
	private String lname;
	private String mname;	
	
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Person(int eid, String fname, String lname, String mname) {
		super();
		this.eid = eid;
		this.fname = fname;
		this.lname = lname;
		this.mname = mname;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	
	
	
	
}
