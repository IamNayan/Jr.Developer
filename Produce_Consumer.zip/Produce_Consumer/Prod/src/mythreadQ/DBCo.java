package mythreadQ;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

class DBCo {
	
		
	List<String> sQueue1;

    public List<String> p() {
	// TODO Auto-generated method stub
 try {
		
		/*String[] aa={"Ma","Sa","S","ssds"};
		Queue<String> queueNames = new LinkedList<>();
		
		for(int i=0;i<aa.length;i++){
		queueNames.add(aa[i]);}
		for(String aaa:queueNames)
		{
			System.out.println(aaa);
		}*/
		System.out.println("=====================");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
		Statement stmt = conn.createStatement();
		ResultSet rs=stmt.executeQuery("select * from ex");
		sQueue1=new ArrayList<String>();
		while(rs.next())
		{
		
			sQueue1.add(rs.getString("n"));				
			
		}
		/*for(String a:sQueue1)
		{
			System.out.println(a);
		}*/
		System.out.println("=========");
		
		
		System.out.println();
		
		
	    }catch (Exception e) {
			// TODO: handle exception
		}

return sQueue1;	
}
}
