package mythreadQ;


import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.stream.Collectors;

class Consumer implements Runnable
{
    private final List<String> taskQueue;
   private final int           MAX_CAPACITY;
   private final String FILE_NAME;
 
   public Consumer(List<String> sharedQueue,int size,String filename)
   {
      this.taskQueue = sharedQueue;
      this.MAX_CAPACITY = size;
      this.FILE_NAME=filename;
   }
 
	
	
   @Override
   public void run()
   {
      while (true)
      {
         try
         {
            consume();
         } catch (InterruptedException | IOException ex)
         {
            ex.printStackTrace();
         }
      }
   }
 
   private void consume() throws InterruptedException, IOException
   {
	   	   
      synchronized (taskQueue)
      {
    	 while (taskQueue.isEmpty())
         {
            System.out.println("Queue is empty " + Thread.currentThread().getName() + " is waiting , size: " + taskQueue.size());
            taskQueue.wait();
         }
         Thread.sleep(4000);
		  
        
		  if(taskQueue != null) {        	 
        	
             try (FileWriter writer = new FileWriter(FILE_NAME,true)) {
                 for(String item : taskQueue) { 
                     writer.write(item + System.lineSeparator());
                    writer.write(" ");
                 }       
                writer.write("\n");
             }
             catch(IOException e) {
                 System.out.println("Problem writing file: " + FILE_NAME +
                                    " in writeAList");
             }

         }
         else {
             System.out.println("Null list passed to writeAList.");
         } 
         
         
         
         
         String i = taskQueue.remove(0);          
         System.out.println("Consumed: "+i);
         /*List<String> myQ= Collections.synchronizedList(new ArrayList<String>());
         myQ.add(i);
         for (String value1 : myQ)
         {
             System.out.println(value1);
         }
         BufferedWriter fileWriter = null;
         try
         {
        	 fileWriter =  new BufferedWriter(new OutputStreamWriter(new         FileOutputStream("C:/filee_5.txt"))); 	 
            

             for (String value : myQ)
             {
                 fileWriter.write(value);
             }
         }
         finally
         {
             if (fileWriter != null)
                 fileWriter.close();
         }*/
         taskQueue.notify();
      }
   }
  }
