package newthread;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Queue;

class Producer implements Runnable
{
  private final List<String> taskQueue;
    private final int           MAX_CAPACITY;
   Iterator iter;
   
   public Producer(List<String> sharedQueue, int size)
   {
      this.taskQueue = sharedQueue;
      this.MAX_CAPACITY = size;
     
   }
	
 
   

@Override
   public void run()
   {
     
	  	   
      List<String> sQueue= Collections.synchronizedList(new ArrayList<String>(2));
      DBCo co=new DBCo();
      sQueue=co.p();
      
      
     
      
      /*sQueue.add("ABC");
      sQueue.add("XSDF");
      sQueue.add("MIYAA");
      sQueue.add("KARN");
      sQueue.add("alex");
      sQueue.add("JAniss");*/
     
      synchronized(sQueue) {
	       iter = sQueue.iterator();}       
      
      while (true)
      {
         try
         {
        	 
        	 while (iter.hasNext()){
                  produce((String) iter.next());}
         } 
         catch (InterruptedException ex)
         {
            ex.printStackTrace();
         } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (NoSuchElementException exception){
         System.out.println("NoSuchElementException, the line was: " +exception);
      }
      }
   }
 
   private void produce(String str) throws InterruptedException, ClassNotFoundException, SQLException
   {
      synchronized (taskQueue)
      {
         while (taskQueue.size() == MAX_CAPACITY)
         {
            System.out.println("Queue is full " + Thread.currentThread().getName() + " is waiting , size: " + taskQueue.size());
            taskQueue.wait();
         }
         
         Thread.sleep(1000);         
         taskQueue.add(str);
         System.out.println("Produced: " + str);
         taskQueue.notify();
      }
      
      
      
   }



   
   
}

