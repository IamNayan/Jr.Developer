package newthread;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;



public class PCMain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* DBCo co=new DBCo();
		 co.p();
		*/
		  List<String> taskQueue = new LinkedList<String>();
	      int MAX_CAPACITY = 2;	
	      String FILE_NAME="C:/file_2.txt";
	      Thread tProducer = new Thread(new Producer(taskQueue, MAX_CAPACITY), "Producer");
	      Thread tConsumer = new Thread(new Consumer(taskQueue, MAX_CAPACITY,FILE_NAME), "Consumer");
	      tProducer.start();
	      tConsumer.start();
	}
}
