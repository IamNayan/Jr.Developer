package mythredQ_Person;


import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.stream.Collectors;

class Consumer implements Runnable
{
    private final  Queue<Person> taskQueue;
    private final int           MAX_CAPACITY;
    private final String FILE_NAME;
 
   public Consumer( Queue<Person> sharedQueue,int size,String filename)
   {
      this.taskQueue = sharedQueue;
      this.MAX_CAPACITY = size;
      this.FILE_NAME=filename;
   }	
	
   @Override
   public void run()
   {
      while (true)
      {
         try
         {
            consume();
         } catch (InterruptedException | IOException ex)
         {
            ex.printStackTrace();
         }
      }
   }
 
   private void consume() throws InterruptedException, IOException
   {
	   	   
      synchronized (taskQueue)
      {
    	 while (taskQueue.isEmpty())
         {
            System.out.println("Queue is empty " + Thread.currentThread().getName() + " is waiting , size: " + taskQueue.size());
            taskQueue.wait();
         }
         Thread.sleep(4000);
		  
         
        //Wrirting to file
		  if(taskQueue != null) {        	 
        	
             try (FileWriter writer = new FileWriter(FILE_NAME,true)) {
                 for(Person item : taskQueue) { 
                     writer.write(item + System.lineSeparator());
                    writer.write(" ");
                 }       
                writer.write("\n");
             }
             catch(IOException e) {
                 System.out.println("Problem writing file: " + FILE_NAME +
                                    " in writeAList");
             }

         }
         else {
             System.out.println("Null list passed to writeAList.");
         }       
         
         
        // taskQueue.remove();
         //Person i = taskQueue.removeF(0);          
         System.out.println("Consumed: "+taskQueue.remove());
         taskQueue.notify();
      }
   }
  }
