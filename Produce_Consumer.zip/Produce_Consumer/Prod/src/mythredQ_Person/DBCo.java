package mythredQ_Person;

import java.util.Queue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class DBCo {

	Queue<Person> sQueue1;
	public Queue<Person> P() throws SQLException {
	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
		Statement stmt = conn.createStatement();
		ResultSet rs=stmt.executeQuery("select * from emp");
		sQueue1 = new LinkedList<>();
		//System.out.println("=========");
		int j;
		while(rs.next())
		{
			sQueue1.add((new Person(rs.getInt(1),
					rs.getString(2),
					rs.getString(3),
					rs.getString(4))));
			
			
		}
		/*for (Person name : sQueue1) {
		    System.out.println(name);
		}*/
		//System.out.println("==========");		
		
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return sQueue1;	
	}
	
}


