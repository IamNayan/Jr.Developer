package mythredQ_Person;



import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class DBAdd  {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		
		// 1. LOAD THE DRIVER
		//System.out.println("Loding Driverss.....");
		Class.forName("com.mysql.jdbc.Driver");		
		// 2. ESTABLISH THE CONNECTION		                           //USER DATABASE USERNAME PASSWORD
		System.out.println("Connecting to mydb......");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
		
		
		// 3.CREATE STAMENT OBJECT
		Statement stmt = conn.createStatement();  
		//normal statement //stament returns you in excute query
			
		
		//using stament you excute upadte it will not return you anything    // ? place holder later it going to change
		
		PreparedStatement pStmt1 = conn.prepareStatement("insert into emp values(?,?,?,?)");
		
  
		int[] results = pStmt1.executeBatch();
		
		System.out.println("Added Successfully");
		
		// 4. EXCUTE QUERY
		pStmt1.executeUpdate();		
		conn.close();
	
	}

}


