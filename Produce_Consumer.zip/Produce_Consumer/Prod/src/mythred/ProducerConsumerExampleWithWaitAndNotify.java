package mythred;

import java.util.ArrayList;
import java.util.List;

public class ProducerConsumerExampleWithWaitAndNotify {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  List<Integer> taskQueue = new ArrayList<Integer>();
	      int MAX_CAPACITY = 2;
	      Thread tProducer = new Thread(new Producer_1(taskQueue, MAX_CAPACITY), "Producer_1");
	      Thread tConsumer = new Thread(new Consumer_1(taskQueue, MAX_CAPACITY), "Consumer_1");
	      tProducer.start();
	      tConsumer.start();
	}

}
