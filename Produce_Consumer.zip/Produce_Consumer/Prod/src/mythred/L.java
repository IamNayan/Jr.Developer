package mythred;

import java.util.*;

public class L {
    private List<Person> listPeople = new ArrayList<Person>();
 
    public void setListPeople(List<Person> list) {
        for (Person aPerson : list) {
            this.listPeople.add((Person) aPerson.clone());
        }
    }
 
    public List<Person> getListPeople() {
        List<Person> listReturn = new ArrayList<Person>();
        for (Person aPerson : this.listPeople) {
            listReturn.add((Person) aPerson.clone());
        }
 
        return listReturn;
    }
 
    public static void main(String[] args) {
        L app = new L();
 
        List<Person> list1 = new ArrayList<Person>();
        list1.add(new Person("Peter"));
        list1.add(new Person("Alice"));
        list1.add(new Person("Mary"));
 
        app.setListPeople(list1);
 
        System.out.println("List 1: " + list1);
 
        list1.get(2).setName("Maryland");
 
        List<Person> list2 = app.getListPeople();
        System.out.println("List 2: " + list2);
 
        list1.get(0).setName("Peter Crouch");
 
        List<Person> list3 = app.getListPeople();
        System.out.println("List 3: " + list3);
 
    }
}